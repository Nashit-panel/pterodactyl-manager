import requests
from pathlib import Path

def get_cidr_ranges(country_code):
    url = f"http://www.ipdeny.com/ipblocks/data/aggregated/{country_code}-aggregated.zone"
    response = requests.get(url)
    if response.status_code == 200:
        return response.text.splitlines()
    return None

def main():
    country = input("Please enter the country code (e.g., 'ir' for Iran): ").strip().lower()
    if len(country) != 2 or not country.isalpha():
        print("The country code must be two letters and in English.")
        return
    
    cidr_ranges = get_cidr_ranges(country)
    if cidr_ranges:
        output_file = f"{country}_cidr.txt"
        file_path = Path(output_file)
        file_path.write_text("\n".join(cidr_ranges) + "\n")
        print(f"{len(cidr_ranges)} IP ranges for country {country} saved to {output_file}.")
    else:
        print(f"Could not retrieve IP ranges for country {country}. Was the country code correct?")

if __name__ == "__main__":
    main()
