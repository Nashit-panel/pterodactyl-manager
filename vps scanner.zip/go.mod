module ssh

go 1.25.3

require (
	github.com/fatih/color v1.18.0
	golang.org/x/crypto v0.43.0
)

require (
	github.com/mattn/go-colorable v0.1.13 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	golang.org/x/sys v0.37.0 // indirect
)
